#!/bin/bash

set -ex

cp $INST_DIR/ubuntu/install/forensic_osint/bg_forensic_osint.png  /usr/share/backgrounds/bg_default.png
