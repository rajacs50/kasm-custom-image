# About This Image

This Image contains an Ubuntu desktop with Google Chrome, and [Forensic OSINT](https://www.forensicosint.com/) Chrome Extension pre-configured.
![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://5856039.fs1.hubspotusercontent-na1.net/hubfs/5856039/dockerhub/image-screenshots/forensic-osint.png "Image Screenshot"

# Environment Variables

* `APP_ARGS` - Additional arguments to pass to the application when launched.