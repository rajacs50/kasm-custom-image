# About This Image

This Image contains a browser-accessible Fedora 38 Desktop with various productivity and development apps installed.

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://info.kasmweb.com/hubfs/dockerhub/image-screenshots/fedora-37-desktop.png "Image Screenshot"
