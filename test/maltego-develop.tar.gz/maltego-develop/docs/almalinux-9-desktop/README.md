# About This Image

This Image contains a browser-accessible AlmaLinux 9 Desktop with various productivity and development apps installed.

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://info.kasmweb.com/hubfs/dockerhub/image-screenshots/almalinux-9-desktop.png "Image Screenshot"
