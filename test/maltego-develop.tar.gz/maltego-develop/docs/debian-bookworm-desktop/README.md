# About This Image

This Image contains a browser-accessible Debian Bookworm Desktop with various productivity and development apps installed.

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://info.kasmweb.com/hubfs/dockerhub/image-screenshots/debian-bullseye-desktop.png "Image Screenshot"
