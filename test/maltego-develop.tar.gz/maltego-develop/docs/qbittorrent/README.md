# About This Image

This Image contains a browser-accessible version of [qBittorrent](https://www.qbittorrent.org/).

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://5856039.fs1.hubspotusercontent-na1.net/hubfs/5856039/dockerhub/qbittorrent.png "Image Screenshot"

# Environment Variables

* `APP_ARGS` - Additional arguments to pass to the application when launched.
