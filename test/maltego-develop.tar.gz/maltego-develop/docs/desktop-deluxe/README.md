# About This Image

This Image contains a browser-accessible Ubuntu Bionic Desktop with various productivity and development apps installed.

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://f.hubspotusercontent30.net/hubfs/5856039/dockerhub/image-screenshots/desktop-deluxe.png "Image Screenshot"