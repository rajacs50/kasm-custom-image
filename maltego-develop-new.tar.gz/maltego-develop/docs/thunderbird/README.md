# About This Image

This Image contains a browser-accessible version of [Thunderbird](https://www.thunderbird.net/).

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://5856039.fs1.hubspotusercontent-na1.net/hubfs/5856039/dockerhub/image-screenshots/thunderbird.png "Image Screenshot"
