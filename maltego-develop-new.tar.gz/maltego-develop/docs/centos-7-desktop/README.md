# About This Image

This Image contains a browser-accessible CentOS 7 XFCE Desktop with Chrome and Firefox installed..

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://f.hubspotusercontent30.net/hubfs/5856039/dockerhub/image-screenshots/centos-7-desktop.png "Image Screenshot"