# About This Image

This Image contains a browser-accessible Ubuntu Bionic Desktop with Chrome and Firefox installed.

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://f.hubspotusercontent30.net/hubfs/5856039/dockerhub/image-screenshots/desktop.png "Image Screenshot"