# About This Image

This Image contains an Ubuntu desktop with Google Chrome, [Hunchly](https://www.hunch.ly/) desktop app and [Hunchly Chrome Addon](https://chrome.google.com/webstore/detail/hunchly-20/amfnegileeghgikpggcebehdepknalbf) pre-configured.


![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://f.hubspotusercontent30.net/hubfs/5856039/dockerhub/image-screenshots/hunchly.png "Image Screenshot"