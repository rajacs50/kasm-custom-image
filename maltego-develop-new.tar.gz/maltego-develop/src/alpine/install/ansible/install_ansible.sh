#!/usr/bin/env bash
set -ex

apk add --no-cache \
  ansible \
  python3
